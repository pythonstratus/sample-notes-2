package gov.irs.sbse.os.ts.csp.elsentity.ele.controller;

import gov.irs.sbse.os.ts.csp.elsentity.ele.dto.ApiResponse;
import gov.irs.sbse.os.ts.csp.elsentity.ele.dto.EntActFilter;
import gov.irs.sbse.os.ts.csp.elsentity.ele.dto.PagedResponse;
import gov.irs.sbse.os.ts.csp.elsentity.ele.model.EntAct;
import gov.irs.sbse.os.ts.csp.elsentity.ele.service.EntActService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/entact")
@CrossOrigin(origins = "*")
public class EntActController {

    private static final String DEFAULT_PAGE_NUMBER = "0";
    private static final String DEFAULT_PAGE_SIZE = "100";
    private static final String DEFAULT_SORT_BY = "actsid";
    private static final String DEFAULT_SORT_DIRECTION = "DESC";

    private final EntActService entActService;

    @Autowired
    public EntActController(EntActService entActService) {
        this.entActService = entActService;
    }

    @GetMapping
    public ResponseEntity<PagedResponse<EntAct>> getAllEntActs(
            @RequestParam(defaultValue = DEFAULT_PAGE_NUMBER) int page,
            @RequestParam(defaultValue = DEFAULT_PAGE_SIZE) int size,
            @RequestParam(defaultValue = DEFAULT_SORT_BY) String sortBy,
            @RequestParam(defaultValue = DEFAULT_SORT_DIRECTION) String sortDir) {
        
        PagedResponse<EntAct> response = entActService.getAllEntActs(page, size, sortBy, sortDir);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/{actsid}")
    public ResponseEntity<ApiResponse> getEntActById(@PathVariable Long actsid) {
        return entActService.getEntActById(actsid)
                .map(entAct -> new ResponseEntity<>(
                        new ApiResponse(true, "EntAct retrieved successfully", entAct),
                        HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(
                        new ApiResponse(false, "EntAct not found with ID: " + actsid),
                        HttpStatus.NOT_FOUND));
    }

    @GetMapping("/filter")
    public ResponseEntity<PagedResponse<EntAct>> getEntActsByFilter(
            @RequestParam(required = false) Long tin,
            @RequestParam(required = false) String tp,
            @RequestParam(required = false) Integer mft,
            @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String endDate,
            @RequestParam(defaultValue = DEFAULT_PAGE_NUMBER) int page,
            @RequestParam(defaultValue = DEFAULT_PAGE_SIZE) int size,
            @RequestParam(defaultValue = DEFAULT_SORT_BY) String sortBy,
            @RequestParam(defaultValue = DEFAULT_SORT_DIRECTION) String sortDir) {
        
        EntActFilter filter = new EntActFilter(tin, tp, mft, startDate, endDate);
        PagedResponse<EntAct> response = entActService.getEntActsByFilter(
                filter, page, size, sortBy, sortDir);
        
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    @GetMapping("/dynamic-sort")
    public ResponseEntity<PagedResponse<EntAct>> getDynamicSortedEntActs(
            @RequestParam(required = false) Long tin,
            @RequestParam(required = false) String tp,
            @RequestParam(defaultValue = DEFAULT_PAGE_NUMBER) int page,
            @RequestParam(defaultValue = DEFAULT_PAGE_SIZE) int size,
            @RequestParam(defaultValue = DEFAULT_SORT_BY) String sortBy,
            @RequestParam(defaultValue = DEFAULT_SORT_DIRECTION) String sortDir) {
        
        PagedResponse<EntAct> response = entActService.getDynamicSortedEntActs(
                tin, tp, page, size, sortBy, sortDir);
        
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
