package gov.irs.sbse.os.ts.csp.elsentity.ele.service;

import gov.irs.sbse.os.ts.csp.elsentity.ele.dto.EntActFilter;
import gov.irs.sbse.os.ts.csp.elsentity.ele.dto.PagedResponse;
import gov.irs.sbse.os.ts.csp.elsentity.ele.model.EntAct;
import gov.irs.sbse.os.ts.csp.elsentity.ele.repository.EntActRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class EntActService {

    private final EntActRepository entActRepository;

    @Autowired
    public EntActService(EntActRepository entActRepository) {
        this.entActRepository = entActRepository;
    }

    @Transactional(readOnly = true)
    public PagedResponse<EntAct> getAllEntActs(int page, int size, String sortBy, String sortDir) {
        // Validate input
        validatePageNumberAndSize(page, size);
        
        // Create pageable instance
        Sort sort = sortDir.equalsIgnoreCase(Sort.Direction.ASC.name()) ? 
                    Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size, sort);

        // Retrieve paginated data
        Page<EntAct> entActsPage = entActRepository.findAll(pageable);
        
        return createPagedResponse(entActsPage);
    }

    @Transactional(readOnly = true)
    public PagedResponse<EntAct> getEntActsByFilter(EntActFilter filter, int page, int size, String sortBy, String sortDir) {
        // Validate input
        validatePageNumberAndSize(page, size);
        
        // Create pageable instance
        Sort sort = sortDir.equalsIgnoreCase(Sort.Direction.ASC.name()) ? 
                    Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size, sort);

        // Simplified filter application - just use TIN and TP
        Page<EntAct> entActsPage = entActRepository.findWithFilters(
            filter.getTin(), filter.getTp(), pageable);
        
        return createPagedResponse(entActsPage);
    }

    @Transactional(readOnly = true)
    public PagedResponse<EntAct> getDynamicSortedEntActs(Long tin, String tp, int page, int size, String sortBy, String sortDir) {
        // Validate input
        validatePageNumberAndSize(page, size);
        
        // Create pageable instance with sorting
        Sort sort = sortDir.equalsIgnoreCase(Sort.Direction.ASC.name()) ? 
                    Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size, sort);

        // Apply filter with dynamic sorting
        Page<EntAct> entActsPage = entActRepository.findWithFilters(tin, tp, pageable);
        
        return createPagedResponse(entActsPage);
    }

    @Transactional(readOnly = true)
    public Optional<EntAct> getEntActById(Long actsid) {
        return entActRepository.findById(actsid);
    }

    // Helper methods
    private void validatePageNumberAndSize(int page, int size) {
        if (page < 0) {
            throw new IllegalArgumentException("Page number cannot be less than zero.");
        }

        if (size < 1) {
            throw new IllegalArgumentException("Size must be greater than zero.");
        }

        if (size > 1000) {
            throw new IllegalArgumentException("Page size too large. Max allowed size is 1000.");
        }
    }
    
    private PagedResponse<EntAct> createPagedResponse(Page<EntAct> page) {
        List<EntAct> content = page.getNumberOfElements() == 0 ? 
                Collections.emptyList() : page.getContent();
                
        return new PagedResponse<>(
            content,
            page.getNumber(),
            page.getSize(),
            page.getTotalElements(),
            page.getTotalPages(),
            page.isLast()
        );
    }
}
