package gov.irs.sbse.os.ts.csp.elsentity.ele.repository;

import gov.irs.sbse.os.ts.csp.elsentity.ele.model.EntAct;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.sql.Date;

@Repository
public interface EntActRepository extends JpaRepository<EntAct, Long> {
    
    // Find by TIN with pagination
    Page<EntAct> findByTin(Long tin, Pageable pageable);
    
    // Find by TP with pagination
    Page<EntAct> findByTpContainingIgnoreCase(String tp, Pageable pageable);
    
    // Find by date range with pagination
    Page<EntAct> findByActdtBetween(Date startDate, Date endDate, Pageable pageable);
    
    // Simplified query for filter - avoid complex JPQL
    @Query("SELECT e FROM EntAct e WHERE " +
           "(:tin IS NULL OR e.tin = :tin) AND " +
           "(:tp IS NULL OR e.tp LIKE CONCAT('%', :tp, '%'))")
    Page<EntAct> findWithFilters(
        @Param("tin") Long tin,
        @Param("tp") String tp,
        Pageable pageable
    );
}
