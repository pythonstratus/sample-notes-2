package gov.irs.sbse.os.ts.csp.elsentity.ele.repository;

import gov.irs.sbse.os.ts.csp.elsentity.ele.model.EntAct;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest
@ActiveProfiles("test")
@TestPropertySource(locations = "classpath:application-test.properties")
class EntActRepositoryTest {

    @Autowired
    private EntActRepository entActRepository;
    
    @PersistenceContext
    private EntityManager entityManager;

    @BeforeEach
    void setUp() {
        // Clear any existing data
        entActRepository.deleteAll();
        entityManager.flush();
        
        // Create and persist test entities with minimal required fields
        EntAct entAct1 = new EntAct();
        entAct1.setActsid(1L);
        entAct1.setTp("Test Taxpayer 1");
        entAct1.setTin(123456789L);
        entAct1.setAmount(new BigDecimal("1000.00"));
        entAct1.setActdt(Date.valueOf(LocalDate.now()));
        
        EntAct entAct2 = new EntAct();
        entAct2.setActsid(2L);
        entAct2.setTp("Test Taxpayer 2");
        entAct2.setTin(123456789L);
        entAct2.setAmount(new BigDecimal("2000.00"));
        entAct2.setActdt(Date.valueOf(LocalDate.now().minusDays(1)));
        
        EntAct entAct3 = new EntAct();
        entAct3.setActsid(3L);
        entAct3.setTp("Another Taxpayer");
        entAct3.setTin(987654321L);
        entAct3.setAmount(new BigDecimal("3000.00"));
        entAct3.setActdt(Date.valueOf(LocalDate.now().minusDays(2)));
        
        // Save entities
        entActRepository.save(entAct1);
        entActRepository.save(entAct2);
        entActRepository.save(entAct3);
        
        // Flush to ensure all entities are persisted
        entityManager.flush();
        entityManager.clear();
    }

    @Test
    void findByTin_ReturnsMatchingRecords() {
        // Arrange
        Pageable pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "actsid"));
        
        // Act
        Page<EntAct> result = entActRepository.findByTin(123456789L, pageable);
        
        // Assert
        assertNotNull(result);
        assertEquals(2, result.getTotalElements());
        List<EntAct> content = result.getContent();
        assertTrue(content.stream().allMatch(e -> e.getTin().equals(123456789L)));
    }
    
    @Test
    void findByTpContainingIgnoreCase_ReturnsMatchingRecords() {
        // Arrange
        Pageable pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.ASC, "actsid"));
        
        // Act
        Page<EntAct> result = entActRepository.findByTpContainingIgnoreCase("test", pageable);
        
        // Assert
        assertNotNull(result);
        assertEquals(2, result.getTotalElements());
    }
    
    @Test
    void findByActdtBetween_ReturnsRecordsInDateRange() {
        // Arrange
        LocalDate today = LocalDate.now();
        LocalDate startDate = today.minusDays(1);
        LocalDate endDate = today;
        
        Pageable pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "actdt"));
        
        // Act
        Page<EntAct> result = entActRepository.findByActdtBetween(
                Date.valueOf(startDate), Date.valueOf(endDate), pageable);
        
        // Assert
        assertNotNull(result);
        assertEquals(2, result.getTotalElements());
    }
    
    @Test
    void findWithFilters_BasicFilterTest() {
        // Arrange
        Pageable pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "actsid"));
        
        // Act - Simple TIN filter
        Page<EntAct> result = entActRepository.findWithFilters(123456789L, null, pageable);
        
        // Assert
        assertNotNull(result);
        assertEquals(2, result.getTotalElements());
        
        // Act - Simple TP filter
        result = entActRepository.findWithFilters(null, "Test", pageable);
        
        // Assert
        assertNotNull(result);
        assertEquals(2, result.getTotalElements());
        
        // Act - Combined filter
        result = entActRepository.findWithFilters(123456789L, "Test", pageable);
        
        // Assert
        assertNotNull(result);
        assertEquals(2, result.getTotalElements());
    }
}
