package gov.irs.sbse.os.ts.csp.elsentity.ele.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Generic API response wrapper for standardized API responses
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApiResponse {
    private Boolean success;
    private String message;
    private Object data;
    
    /**
     * Constructor for simple responses without data
     * 
     * @param success Success flag
     * @param message Response message
     */
    public ApiResponse(Boolean success, String message) {
        this.success = success;
        this.message = message;
        this.data = null;
    }
}
