package gov.irs.sbse.os.ts.csp.elsentity.ele.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Wrapper for paginated responses
 * Includes content and pagination metadata
 * 
 * @param <T> Type of content in the paged response
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PagedResponse<T> {
    private List<T> content;           // Page content
    private int page;                  // Current page number (0-based)
    private int size;                  // Page size
    private long totalElements;        // Total number of elements across all pages
    private int totalPages;            // Total number of pages
    private boolean last;              // Whether this is the last page
}
