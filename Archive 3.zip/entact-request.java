package gov.irs.sbse.os.ts.csp.elsentity.ele.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Request DTO for creating/updating EntAct
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EntActRequest {
    private String tp;
    private Long tin;
    private Integer tintt;
    private Integer tinfs;
    private Long roid;
    private String actdt; // Format: YYYY-MM-DD
    private Integer mft;
    private String period; // Format: YYYY-MM-DD
    private BigDecimal amount;
    private String form809;
    private String rtnsec;
    private Integer dispcode;
    private Integer grpind;
    private Integer tc;
    private Integer cc;
    private String rptcd;
    private String rptdef;
    private String typcd;
    private String extrdt; // Format: YYYY-MM-DD
    private String code;
    private String subcode;
    private String empidnum;
    private String inputdate; // Format: YYYY-MM-DD
    private Long inputtime;
    private Long typeid;
    private String tsactcd;
}
