package gov.irs.sbse.os.ts.csp.elsentity.ele.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Filter parameters for EntAct queries
 * Used to filter entity activities by various criteria
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EntActFilter {
    private Long tin;
    private String tp;
    private Integer mft;
    private String startDate; // Format: YYYY-MM-DD
    private String endDate;   // Format: YYYY-MM-DD
}
