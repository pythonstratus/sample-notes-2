package gov.irs.sbse.os.ts.csp.elsentity.ele.repository;

import gov.irs.sbse.os.ts.csp.elsentity.ele.model.EntAct;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest
@ActiveProfiles("test")
class EntActRepositoryTest {

    @Autowired
    private EntActRepository entActRepository;

    // Helper method to create test entities
    private EntAct createTestEntAct(Long actsid, String tp, Long tin, Integer mft, Date actdt, BigDecimal amount) {
        EntAct entAct = new EntAct();
        entAct.setActsid(actsid);
        entAct.setTp(tp);
        entAct.setTin(tin);
        entAct.setMft(mft);
        entAct.setActdt(actdt);
        entAct.setAmount(amount);
        return entAct;
    }

    @Test
    void findByTin_ReturnsMatchingRecords() {
        // Arrange
        EntAct entAct1 = createTestEntAct(1L, "Test Taxpayer 1", 123456789L, 30, 
                Date.valueOf(LocalDate.now()), new BigDecimal("1000.00"));
        EntAct entAct2 = createTestEntAct(2L, "Test Taxpayer 2", 123456789L, 31, 
                Date.valueOf(LocalDate.now().minusDays(1)), new BigDecimal("2000.00"));
        EntAct entAct3 = createTestEntAct(3L, "Test Taxpayer 3", 987654321L, 30, 
                Date.valueOf(LocalDate.now().minusDays(2)), new BigDecimal("3000.00"));
        
        entActRepository.save(entAct1);
        entActRepository.save(entAct2);
        entActRepository.save(entAct3);
        
        Pageable pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "actsid"));
        
        // Act
        Page<EntAct> result = entActRepository.findByTin(123456789L, pageable);
        
        // Assert
        assertNotNull(result);
        assertEquals(2, result.getTotalElements());
        assertTrue(result.getContent().stream()
                .allMatch(e -> e.getTin().equals(123456789L)));
    }
    
    @Test
    void findByTpContainingIgnoreCase_ReturnsMatchingRecords() {
        // Arrange
        EntAct entAct1 = createTestEntAct(1L, "ABC Company", 123456789L, 30, 
                Date.valueOf(LocalDate.now()), new BigDecimal("1000.00"));
        EntAct entAct2 = createTestEntAct(2L, "XYZ Corporation", 987654321L, 31, 
                Date.valueOf(LocalDate.now().minusDays(1)), new BigDecimal("2000.00"));
        EntAct entAct3 = createTestEntAct(3L, "ABC Enterprises", 555555555L, 30, 
                Date.valueOf(LocalDate.now().minusDays(2)), new BigDecimal("3000.00"));
        
        entActRepository.save(entAct1);
        entActRepository.save(entAct2);
        entActRepository.save(entAct3);
        
        Pageable pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.ASC, "actsid"));
        
        // Act
        Page<EntAct> result = entActRepository.findByTpContainingIgnoreCase("abc", pageable);
        
        // Assert
        assertNotNull(result);
        assertEquals(2, result.getTotalElements());
        assertTrue(result.getContent().stream()
                .allMatch(e -> e.getTp().toLowerCase().contains("abc")));
    }
    
    @Test
    void findByActdtBetween_ReturnsRecordsInDateRange() {
        // Arrange
        LocalDate today = LocalDate.now();
        LocalDate startDate = today.minusDays(5);
        LocalDate endDate = today;
        
        EntAct entAct1 = createTestEntAct(1L, "Test 1", 123456789L, 30, 
                Date.valueOf(today), new BigDecimal("1000.00"));
        EntAct entAct2 = createTestEntAct(2L, "Test 2", 987654321L, 31, 
                Date.valueOf(today.minusDays(3)), new BigDecimal("2000.00"));
        EntAct entAct3 = createTestEntAct(3L, "Test 3", 555555555L, 30, 
                Date.valueOf(today.minusDays(10)), new BigDecimal("3000.00"));
        
        entActRepository.save(entAct1);
        entActRepository.save(entAct2);
        entActRepository.save(entAct3);
        
        Pageable pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "actdt"));
        
        // Act
        Page<EntAct> result = entActRepository.findByActdtBetween(
                Date.valueOf(startDate), Date.valueOf(endDate), pageable);
        
        // Assert
        assertNotNull(result);
        assertEquals(2, result.getTotalElements());
        assertTrue(result.getContent().stream()
                .allMatch(e -> !e.getActdt().before(Date.valueOf(startDate)) 
                           && !e.getActdt().after(Date.valueOf(endDate))));
    }
    
    @Test
    void findWithFilters_ReturnsFilteredRecords() {
        // Arrange
        LocalDate today = LocalDate.now();
        
        EntAct entAct1 = createTestEntAct(1L, "ABC Company", 123456789L, 30, 
                Date.valueOf(today), new BigDecimal("1000.00"));
        EntAct entAct2 = createTestEntAct(2L, "XYZ Corporation", 123456789L, 31, 
                Date.valueOf(today.minusDays(3)), new BigDecimal("2000.00"));
        EntAct entAct3 = createTestEntAct(3L, "ABC Enterprises", 555555555L, 30, 
                Date.valueOf(today.minusDays(5)), new BigDecimal("3000.00"));
        
        entActRepository.save(entAct1);
        entActRepository.save(entAct2);
        entActRepository.save(entAct3);
        
        Pageable pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "actsid"));
        
        // Act
        Page<EntAct> result = entActRepository.findWithFilters(
                123456789L, null, 30, 
                Date.valueOf(today.minusDays(7)), Date.valueOf(today), 
                pageable);
        
        // Assert
        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
        assertEquals(entAct1.getActsid(), result.getContent().get(0).getActsid());
    }
    
    @Test
    void findWithDynamicSorting_ReturnsSortedRecords() {
        // Arrange
        EntAct entAct1 = createTestEntAct(1L, "ABC Company", 123456789L, 30, 
                Date.valueOf(LocalDate.now()), new BigDecimal("1000.00"));
        EntAct entAct2 = createTestEntAct(2L, "XYZ Corporation", 123456789L, 31, 
                Date.valueOf(LocalDate.now().minusDays(1)), new BigDecimal("3000.00"));
        EntAct entAct3 = createTestEntAct(3L, "MNO Inc", 123456789L, 30, 
                Date.valueOf(LocalDate.now().minusDays(2)), new BigDecimal("2000.00"));
        
        entActRepository.save(entAct1);
        entActRepository.save(entAct2);
        entActRepository.save(entAct3);
        
        Pageable pageable = PageRequest.of(0, 10);
        
        // Act - Sort by amount ascending
        Page<EntAct> result = entActRepository.findWithDynamicSorting(
                123456789L, null, "amount", "ASC", pageable);
        
        // Assert
        assertNotNull(result);
        assertEquals(3, result.getTotalElements());
        assertEquals(entAct1.getActsid(), result.getContent().get(0).getActsid());
        assertEquals(entAct3.getActsid(), result.getContent().get(1).getActsid());
        assertEquals(entAct2.getActsid(), result.getContent().get(2).getActsid());
        
        // Act - Sort by amount descending
        result = entActRepository.findWithDynamicSorting(
                123456789L, null, "amount", "DESC", pageable);
        
        // Assert
        assertNotNull(result);
        assertEquals(3, result.getTotalElements());
        assertEquals(entAct2.getActsid(), result.getContent().get(0).getActsid());
        assertEquals(entAct3.getActsid(), result.getContent().get(1).getActsid());
        assertEquals(entAct1.getActsid(), result.getContent().get(2).getActsid());
    }
    
    @Test
    void findWithFilters_MultipleFilterCombinations() {
        // Arrange
        LocalDate today = LocalDate.now();
        
        EntAct entAct1 = createTestEntAct(1L, "ABC Company", 123456789L, 30, 
                Date.valueOf(today), new BigDecimal("1000.00"));
        EntAct entAct2 = createTestEntAct(2L, "ABC Corporation", 123456789L, 31, 
                Date.valueOf(today.minusDays(3)), new BigDecimal("2000.00"));
        EntAct entAct3 = createTestEntAct(3L, "XYZ Enterprises", 555555555L, 30, 
                Date.valueOf(today.minusDays(5)), new BigDecimal("3000.00"));
        
        entActRepository.save(entAct1);
        entActRepository.save(entAct2);
        entActRepository.save(entAct3);
        
        Pageable pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "actsid"));
        
        // Test: TIN + MFT filter
        Page<EntAct> result = entActRepository.findWithFilters(
                123456789L, null, 30, null, null, pageable);
        
        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
        assertEquals(entAct1.getActsid(), result.getContent().get(0).getActsid());
        
        // Test: TP filter only
        result = entActRepository.findWithFilters(
                null, "ABC", null, null, null, pageable);
        
        assertNotNull(result);
        assertEquals(2, result.getTotalElements());
        
        // Test: Date range only
        result = entActRepository.findWithFilters(
                null, null, null, 
                Date.valueOf(today.minusDays(4)), Date.valueOf(today), 
                pageable);
        
        assertNotNull(result);
        assertEquals(2, result.getTotalElements());
    }
    
    @Test
    void findWithFilters_NoMatchingResults() {
        // Arrange
        LocalDate today = LocalDate.now();
        
        EntAct entAct1 = createTestEntAct(1L, "ABC Company", 123456789L, 30, 
                Date.valueOf(today), new BigDecimal("1000.00"));
        
        entActRepository.save(entAct1);
        
        Pageable pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "actsid"));
        
        // Act - Use non-existent TIN
        Page<EntAct> result = entActRepository.findWithFilters(
                999999999L, null, null, null, null, pageable);
        
        // Assert
        assertNotNull(result);
        assertEquals(0, result.getTotalElements());
        assertTrue(result.getContent().isEmpty());
    }
}
