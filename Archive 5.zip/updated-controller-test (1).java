package gov.irs.sbse.os.ts.csp.elsentity.ele.controller;

import gov.irs.sbse.os.ts.csp.elsentity.ele.dto.ApiResponse;
import gov.irs.sbse.os.ts.csp.elsentity.ele.dto.EntActFilter;
import gov.irs.sbse.os.ts.csp.elsentity.ele.dto.PagedResponse;
import gov.irs.sbse.os.ts.csp.elsentity.ele.model.EntAct;
import gov.irs.sbse.os.ts.csp.elsentity.ele.service.EntActService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

class EntActControllerTest {

    @Mock
    private EntActService entActService;

    @InjectMocks
    private EntActController entActController;

    private EntAct entAct;
    private List<EntAct> entActList;
    private PagedResponse<EntAct> pagedResponse;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // Create sample EntAct
        entAct = new EntAct();
        entAct.setActsid(1L);
        entAct.setTp("Test Taxpayer");
        entAct.setTin(123456789L);
        entAct.setAmount(new BigDecimal("1000.00"));
        entAct.setActdt(Date.valueOf(LocalDate.now()));
        entAct.setMft(30);

        // Create sample list
        entActList = new ArrayList<>();
        entActList.add(entAct);

        // Create sample paged response
        pagedResponse = new PagedResponse<>(
                entActList,
                0,
                10,
                1,
                1,
                true
        );
    }

    @Test
    void getAllEntActs_ReturnsPagedResponse() {
        // Arrange
        when(entActService.getAllEntActs(anyInt(), anyInt(), anyString(), anyString()))
                .thenReturn(pagedResponse);

        // Act
        ResponseEntity<PagedResponse<EntAct>> response = entActController.getAllEntActs(0, 10, "actsid", "DESC");

        // Assert
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1, response.getBody().getContent().size());
        assertEquals(entAct.getActsid(), response.getBody().getContent().get(0).getActsid());
    }

    @Test
    void getEntActById_WhenExists_ReturnsEntAct() {
        // Arrange
        when(entActService.getEntActById(anyLong())).thenReturn(Optional.of(entAct));

        // Act
        ResponseEntity<ApiResponse> response = entActController.getEntActById(1L);

        // Assert
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(true, response.getBody().getSuccess());
        assertEquals(entAct, response.getBody().getData());
    }

    @Test
    void getEntActById_WhenNotExists_ReturnsNotFound() {
        // Arrange
        when(entActService.getEntActById(anyLong())).thenReturn(Optional.empty());

        // Act
        ResponseEntity<ApiResponse> response = entActController.getEntActById(999L);

        // Assert
        assertNotNull(response);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(false, response.getBody().getSuccess());
    }

    @Test
    void getEntActsByFilter_ReturnsFilteredResults() {
        // Arrange
        when(entActService.getEntActsByFilter(any(EntActFilter.class), anyInt(), anyInt(), anyString(), anyString()))
                .thenReturn(pagedResponse);

        // Act
        ResponseEntity<PagedResponse<EntAct>> response = entActController.getEntActsByFilter(
                123456789L, "Test", 30, "2023-01-01", "2023-12-31", 0, 10, "actsid", "DESC");

        // Assert
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1, response.getBody().getContent().size());
    }

    @Test
    void getDynamicSortedEntActs_ReturnsSortedResults() {
        // Arrange
        when(entActService.getDynamicSortedEntActs(anyLong(), anyString(), anyInt(), anyInt(), anyString(), anyString()))
                .thenReturn(pagedResponse);

        // Act
        ResponseEntity<PagedResponse<EntAct>> response = entActController.getDynamicSortedEntActs(
                123456789L, "Test", 0, 10, "amount", "ASC");

        // Assert
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1, response.getBody().getContent().size());
    }
    
    @Test
    void getAllEntActs_WithEmptyResults_ReturnsEmptyPage() {
        // Arrange
        PagedResponse<EntAct> emptyResponse = new PagedResponse<>(
                new ArrayList<>(),
                0,
                10,
                0,
                0,
                true
        );
        when(entActService.getAllEntActs(anyInt(), anyInt(), anyString(), anyString()))
                .thenReturn(emptyResponse);

        // Act
        ResponseEntity<PagedResponse<EntAct>> response = entActController.getAllEntActs(0, 10, "actsid", "DESC");

        // Assert
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(0, response.getBody().getContent().size());
        assertEquals(0, response.getBody().getTotalElements());
        assertEquals(0, response.getBody().getTotalPages());
    }
    
    @Test
    void getEntActsByFilter_WithInvalidDateRange_ReturnsEmptyResults() {
        // Arrange
        // Future date range should result in no results
        PagedResponse<EntAct> emptyResponse = new PagedResponse<>(
                new ArrayList<>(),
                0,
                10,
                0,
                0,
                true
        );
        when(entActService.getEntActsByFilter(any(EntActFilter.class), anyInt(), anyInt(), anyString(), anyString()))
                .thenReturn(emptyResponse);

        // Act - Use future dates for search
        ResponseEntity<PagedResponse<EntAct>> response = entActController.getEntActsByFilter(
                123456789L, "Test", 30, "2030-01-01", "2030-12-31", 0, 10, "actsid", "DESC");

        // Assert
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(0, response.getBody().getContent().size());
    }
}
