/**
 * Contains RDBMS-specific SODA interfaces and classes.
 * <p>
 * These are used by the Oracle RDBMS-based implementation.
 * </p>
 */
package oracle.soda.rdbms;
