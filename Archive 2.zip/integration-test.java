package gov.irs.sbse.os.ts.csp.elsentity.ele;

import gov.irs.sbse.os.ts.csp.elsentity.ele.model.EntAct;
import gov.irs.sbse.os.ts.csp.elsentity.ele.repository.EntActRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Arrays;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Transactional
class EntActIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private EntActRepository entActRepository;

    @BeforeEach
    void setUp() {
        // Clear any existing data
        entActRepository.deleteAll();

        // Create test entities
        EntAct entAct1 = createTestEntAct(1L, "Test Taxpayer 1", 123456789L, 30, 
                Date.valueOf(LocalDate.now()), new BigDecimal("1000.00"));
        EntAct entAct2 = createTestEntAct(2L, "Test Taxpayer 2", 123456789L, 31, 
                Date.valueOf(LocalDate.now().minusDays(1)), new BigDecimal("2000.00"));
        EntAct entAct3 = createTestEntAct(3L, "Another Taxpayer", 987654321L, 30, 
                Date.valueOf(LocalDate.now().minusDays(2)), new BigDecimal("3000.00"));

        // Save test entities
        entActRepository.saveAll(Arrays.asList(entAct1, entAct2, entAct3));
    }

    // Helper method to create test entities
    private EntAct createTestEntAct(Long actsid, String tp, Long tin, Integer mft, Date actdt, BigDecimal amount) {
        EntAct entAct = new EntAct();
        entAct.setActsid(actsid);
        entAct.setTp(tp);
        entAct.setTin(tin);
        entAct.setMft(mft);
        entAct.setActdt(actdt);
        entAct.setAmount(amount);
        entAct.setTintt(1);
        entAct.setTinfs(1);
        entAct.setRoid(12345678L);
        entAct.setAroid(12345678L);
        entAct.setDispcode(1);
        entAct.setGrpind(0);
        entAct.setCode("ABC");
        entAct.setSubcode("XYZ");
        return entAct;
    }

    @Test
    void getAllEntActs_ReturnsAllEntities() throws Exception {
        mockMvc.perform(get("/api/entact")
                .contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content", hasSize(3)))
                .andExpect(jsonPath("$.totalElements", is(3)))
                .andExpect(jsonPath("$.totalPages", is(1)))
                .andExpect(jsonPath("$.last", is(true)));
    }

    @Test
    void getEntActById_WhenExists_ReturnsEntity() throws Exception {
        mockMvc.perform(get("/api/entact/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success", is(true)))
                .andExpect(jsonPath("$.data.actsid", is(1)))
                .andExpect(jsonPath("$.data.tp", is("Test Taxpayer 1")))
                .andExpect(jsonPath("$.data.tin", is(123456789)));
    }

    @Test
    void getEntActById_WhenNotExists_ReturnsNotFound() throws Exception {
        mockMvc.perform(get("/api/entact/999")
                .contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.success", is(false)))
                .andExpect(jsonPath("$.message").exists());
    }

    @Test
    void getEntActsByFilter_ReturnsFilteredEntities() throws Exception {
        mockMvc.perform(get("/api/entact/filter")
                .param("tin", "123456789")
                .param("mft", "30")
                .contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content", hasSize(1)))
                .andExpect(jsonPath("$.content[0].actsid", is(1)))
                .andExpect(jsonPath("$.totalElements", is(1)));
    }

    @Test
    void getEntActsByFilter_WithPartialTp_ReturnsMatchingEntities() throws Exception {
        mockMvc.perform(get("/api/entact/filter")
                .param("tp", "Test")
                .contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content", hasSize(2)))
                .andExpect(jsonPath("$.totalElements", is(2)));
    }

    @Test
    void getDynamicSortedEntActs_SortsEntitiesCorrectly() throws Exception {
        // Test sorting by amount in ascending order
        mockMvc.perform(get("/api/entact/dynamic-sort")
                .param("sortBy", "amount")
                .param("sortDir", "ASC")
                .contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content", hasSize(3)))
                .andExpect(jsonPath("$.content[0].amount", is(1000.00)))
                .andExpect(jsonPath("$.content[1].amount", is(2000.00)))
                .andExpect(jsonPath("$.content[2].amount", is(3000.00)));

        // Test sorting by amount in descending order
        mockMvc.perform(get("/api/entact/dynamic-sort")
                .param("sortBy", "amount")
                .param("sortDir", "DESC")
                .contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content", hasSize(3)))
                .andExpect(jsonPath("$.content[0].amount", is(3000.00)))
                .andExpect(jsonPath("$.content[1].amount", is(2000.00)))
                .andExpect(jsonPath("$.content[2].amount", is(1000.00)));
    }

    @Test
    void getAllEntActs_WithPagination_ReturnsPaginatedResults() throws Exception {
        mockMvc.perform(get("/api/entact")
                .param("page", "0")
                .param("size", "2")
                .contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content", hasSize(2)))
                .andExpect(jsonPath("$.totalElements", is(3)))
                .andExpect(jsonPath("$.totalPages", is(2)))
                .andExpect(jsonPath("$.last", is(false)));

        mockMvc.perform(get("/api/entact")
                .param("page", "1")
                .param("size", "2")
                .contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content", hasSize(1)))
                .andExpect(jsonPath("$.totalElements", is(3)))
                .andExpect(jsonPath("$.totalPages", is(2)))
                .andExpect(jsonPath("$.last", is(true)));
    }
}
