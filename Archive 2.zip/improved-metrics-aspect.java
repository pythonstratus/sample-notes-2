package gov.irs.sbse.os.ts.csp.elsentity.ele.aspect;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tag;
import io.micrometer.core.instrument.Timer;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Aspect for collecting metrics on API calls and database operations
 * Works with any entity controller and repository
 */
@Aspect
@Component
public class ImprovedMetricsAspect {

    private final MeterRegistry meterRegistry;

    @Autowired
    public ImprovedMetricsAspect(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
    }

    /**
     * Track API controller methods execution time and count for all controllers
     * in the controller package
     */
    @Around("execution(* gov.irs.sbse.os.ts.csp.elsentity.ele.controller.*Controller.*(..))")
    public Object trackApiRequests(ProceedingJoinPoint joinPoint) throws Throwable {
        // Extract controller and method name for tagging
        String controllerName = joinPoint.getTarget().getClass().getSimpleName();
        String methodName = joinPoint.getSignature().getName();
        
        // Create tags for better metrics categorization
        List<Tag> tags = Arrays.asList(
            Tag.of("controller", controllerName),
            Tag.of("method", methodName)
        );
        
        // Increment request counter with tags
        Counter.builder("api.requests.total")
                .tags(tags)
                .description("Total number of API requests")
                .register(meterRegistry)
                .increment();
        
        // Create timer with tags
        Timer timer = Timer.builder("api.request.duration")
                .tags(tags)
                .description("API request duration")
                .register(meterRegistry);
        
        // Execute and time method
        return timer.record(() -> {
            try {
                return joinPoint.proceed();
            } catch (Throwable e) {
                // Add additional tag for errors and increment error counter
                Counter.builder("api.errors.total")
                        .tags(tags)
                        .tag("exception", e.getClass().getSimpleName())
                        .description("Total number of API errors")
                        .register(meterRegistry)
                        .increment();
                throw new RuntimeException(e);
            }
        });
    }

    /**
     * Track database repository methods execution time and count for all repositories
     * in the repository package
     */
    @Around("execution(* gov.irs.sbse.os.ts.csp.elsentity.ele.repository.*Repository.*(..))")
    public Object trackDatabaseQueries(ProceedingJoinPoint joinPoint) throws Throwable {
        // Extract repository and method name for tagging
        String repositoryName = joinPoint.getTarget().getClass().getSimpleName();
        String methodName = joinPoint.getSignature().getName();
        
        // Extract entity type from repository name
        String entityType = repositoryName.replaceAll("Repository.*", "");
        
        // Create tags for better metrics categorization
        List<Tag> tags = Arrays.asList(
            Tag.of("repository", repositoryName),
            Tag.of("method", methodName),
            Tag.of("entity", entityType)
        );
        
        // Increment query counter with tags
        Counter.builder("database.queries.total")
                .tags(tags)
                .description("Total number of database queries")
                .register(meterRegistry)
                .increment();
        
        // Create timer with tags
        Timer timer = Timer.builder("database.query.duration")
                .tags(tags)
                .description("Database query duration")
                .register(meterRegistry);
        
        // Execute and time method
        return timer.record(() -> {
            try {
                return joinPoint.proceed();
            } catch (Throwable e) {
                // Add additional tag for errors and increment error counter
                Counter.builder("database.errors.total")
                        .tags(tags)
                        .tag("exception", e.getClass().getSimpleName())
                        .description("Total number of database errors")
                        .register(meterRegistry)
                        .increment();
                throw new RuntimeException(e);
            }
        });
    }

    /**
     * Track health check requests
     */
    @Around("execution(* gov.irs.sbse.os.ts.csp.elsentity.ele.controller.HealthController.*(..))")
    public Object trackHealthChecks(ProceedingJoinPoint joinPoint) throws Throwable {
        String methodName = joinPoint.getSignature().getName();
        
        // Create tags for better metrics categorization
        List<Tag> tags = Arrays.asList(
            Tag.of("controller", "HealthController"),
            Tag.of("method", methodName)
        );
        
        // Increment health check counter with tags
        Counter.builder("health.checks.total")
                .tags(tags)
                .description("Total number of health check requests")
                .register(meterRegistry)
                .increment();
        
        // Create timer with tags
        Timer timer = Timer.builder("health.check.duration")
                .tags(tags)
                .description("Health check duration")
                .register(meterRegistry);
                
        return timer.record(() -> {
            try {
                return joinPoint.proceed();
            } catch (Throwable e) {
                throw new RuntimeException(e);
            }
        });
    }
    
    /**
     * Track service layer methods execution time and count for all services
     */
    @Around("execution(* gov.irs.sbse.os.ts.csp.elsentity.ele.service.*Service.*(..))")
    public Object trackServiceMethods(ProceedingJoinPoint joinPoint) throws Throwable {
        // Extract service and method name for tagging
        String serviceName = joinPoint.getTarget().getClass().getSimpleName();
        String methodName = joinPoint.getSignature().getName();
        
        // Create tags for better metrics categorization
        List<Tag> tags = Arrays.asList(
            Tag.of("service", serviceName),
            Tag.of("method", methodName)
        );
        
        // Increment service call counter with tags
        Counter.builder("service.calls.total")
                .tags(tags)
                .description("Total number of service calls")
                .register(meterRegistry)
                .increment();
        
        // Create timer with tags
        Timer timer = Timer.builder("service.call.duration")
                .tags(tags)
                .description("Service call duration")
                .register(meterRegistry);
        
        // Execute and time method
        return timer.record(() -> {
            try {
                return joinPoint.proceed();
            } catch (Throwable e) {
                // Add additional tag for errors and increment error counter
                Counter.builder("service.errors.total")
                        .tags(tags)
                        .tag("exception", e.getClass().getSimpleName())
                        .description("Total number of service errors")
                        .register(meterRegistry)
                        .increment();
                throw new RuntimeException(e);
            }
        });
    }
}
