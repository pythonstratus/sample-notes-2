package gov.irs.sbse.os.ts.csp.elsentity.ele.controller;

import gov.irs.sbse.os.ts.csp.elsentity.ele.service.HealthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

/**
 * Controller for health and monitoring endpoints
 */
@RestController
@RequestMapping("/api/health")
public class HealthController {

    private final HealthService healthService;

    @Autowired
    public HealthController(HealthService healthService) {
        this.healthService = healthService;
    }

    /**
     * Simple heartbeat endpoint that shows basic system status
     * @return Basic status of the application
     */
    @GetMapping("/heartbeat")
    public ResponseEntity<Map<String, Object>> getHeartbeat() {
        Map<String, Object> response = new HashMap<>();
        
        // Basic information
        response.put("applicationName", "Entity Service API");
        response.put("status", "UP");
        response.put("timestamp", LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME));
        
        return ResponseEntity.ok(response);
    }

    /**
     * Comprehensive health check endpoint showing all services status
     * @return Detailed health status of all services
     */
    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> getHealthStatus() {
        Map<String, Object> response = new HashMap<>();
        Map<String, Map<String, Object>> servicesStatus = healthService.checkAllServices();
        
        // Check if any service is not OK
        boolean allServicesOk = servicesStatus.values().stream()
                .allMatch(serviceDetails -> "OK".equals(serviceDetails.get("status")));
        
        // Add global status
        response.put("overallStatus", allServicesOk ? "OK" : "NOT-OK");
        response.put("timestamp", LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME));
        response.put("servicesDetails", servicesStatus);
        
        // Determine response status code
        HttpStatus httpStatus = allServicesOk ? HttpStatus.OK : HttpStatus.SERVICE_UNAVAILABLE;
        
        return ResponseEntity.status(httpStatus).body(response);
    }
    
    /**
     * Minimal health check for load balancers and monitoring tools
     * Returns 200 OK if the service is up, or appropriate error code if it's not
     * @return Empty response with appropriate status code
     */
    @GetMapping(value = "/ping", produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> ping() {
        // Check database connection as critical dependency
        Map<String, Object> dbStatus = healthService.checkAllServices().get("database");
        
        if ("OK".equals(dbStatus.get("status"))) {
            return ResponseEntity.ok("PONG");
        } else {
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body("ERROR");
        }
    }
    
    /**
     * Detailed system information for diagnostics
     * @return System and environment information
     */
    @GetMapping("/info")
    public ResponseEntity<Map<String, Object>> getSystemInfo() {
        Map<String, Object> response = new HashMap<>();
        
        // Runtime information
        Runtime runtime = Runtime.getRuntime();
        Map<String, Object> runtimeInfo = new HashMap<>();
        runtimeInfo.put("availableProcessors", runtime.availableProcessors());
        runtimeInfo.put("maxMemory", runtime.maxMemory());
        runtimeInfo.put("totalMemory", runtime.totalMemory());
        runtimeInfo.put("freeMemory", runtime.freeMemory());
        
        // JVM information
        Map<String, Object> jvmInfo = new HashMap<>();
        jvmInfo.put("javaVersion", System.getProperty("java.version"));
        jvmInfo.put("javaVendor", System.getProperty("java.vendor"));
        jvmInfo.put("javaHome", System.getProperty("java.home"));
        
        // OS information
        Map<String, Object> osInfo = new HashMap<>();
        osInfo.put("osName", System.getProperty("os.name"));
        osInfo.put("osVersion", System.getProperty("os.version"));
        osInfo.put("osArch", System.getProperty("os.arch"));
        
        // Add all to response
        response.put("timestamp", LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME));
        response.put("runtime", runtimeInfo);
        response.put("jvm", jvmInfo);
        response.put("os", osInfo);
        
        return ResponseEntity.ok(response);
    }
}
