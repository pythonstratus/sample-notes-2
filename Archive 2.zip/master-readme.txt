# Entity Service API

A scalable Spring Boot REST API service for retrieving data from Oracle database tables with efficient pagination, sorting, and health monitoring.

## Project Overview

This project provides a robust backend service to retrieve and display entity data from Oracle database tables. It's designed to handle millions of rows efficiently by implementing database-side pagination and optimized queries. The application includes comprehensive health monitoring and metrics collection.

Key features:
- REST API endpoints with pagination and sorting
- Efficient Oracle-specific queries for large datasets
- Support for complex filtering
- Comprehensive health monitoring and metrics
- Integration with Prometheus for observability
- React frontend integration

## Project Structure

```
entity-service/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── gov/
│   │   │       └── irs/
│   │   │           └── sbse/
│   │   │               └── os/
│   │   │                   └── ts/
│   │   │                       └── csp/
│   │   │                           └── elsentity/
│   │   │                               └── ele/
│   │   │                                   ├── App.java
│   │   │                                   ├── aspect/
│   │   │                                   │   └── MetricsAspect.java
│   │   │                                   ├── config/
│   │   │                                   │   ├── HealthConfiguration.java
│   │   │                                   │   └── PrometheusConfiguration.java
│   │   │                                   ├── controller/
│   │   │                                   │   ├── EntActController.java
│   │   │                                   │   └── HealthController.java
│   │   │                                   ├── dto/
│   │   │                                   │   ├── ApiResponse.java
│   │   │                                   │   ├── EntActFilter.java
│   │   │                                   │   ├── EntActRequest.java
│   │   │                                   │   └── PagedResponse.java
│   │   │                                   ├── model/
│   │   │                                   │   └── EntAct.java
│   │   │                                   ├── repository/
│   │   │                                   │   └── EntActRepository.java
│   │   │                                   └── service/
│   │   │                                       ├── EntActService.java
│   │   │                                       └── HealthService.java
│   │   └── resources/
│   │       ├── application.properties
│   │       ├── application-dev.properties
│   │       └── application-prod.properties
│   └── test/
│       ├── java/
│       │   └── gov/
│       │       └── irs/
│       │           └── sbse/
│       │               └── os/
│       │                   └── ts/
│       │                       └── csp/
│       │                           └── elsentity/
│       │                               └── ele/
│       │                                   ├── EntActIntegrationTest.java
│       │                                   ├── controller/
│       │                                   │   ├── EntActControllerTest.java
│       │                                   │   └── HealthControllerTest.java
│       │                                   ├── repository/
│       │                                   │   └── EntActRepositoryTest.java
│       │                                   └── service/
│       │                                       ├── EntActServiceTest.java
│       │                                       └── HealthServiceTest.java
│       └── resources/
│           └── application-test.properties
├── docs/
│   ├── Health API Documentation.md
│   ├── Implementation Guide.md
│   └── Testing Guide.md
├── pom.xml
└── README.md
```

## File Organization by Component

### Core Application

- `App.java` - Main application class with Spring Boot initialization

### Configuration Files

- `config/HealthConfiguration.java` - Configuration for health indicators
- `config/PrometheusConfiguration.java` - Configuration for Prometheus metrics

### Aspect Oriented Programming

- `aspect/MetricsAspect.java` - Aspect for collecting metrics on API and database operations

### Controllers (API Endpoints)

- `controller/EntActController.java` - REST endpoints for EntAct entity
- `controller/HealthController.java` - Health and status endpoints

### Data Transfer Objects (DTOs)

- `dto/ApiResponse.java` - Generic API response wrapper
- `dto/EntActFilter.java` - Filter parameters for EntAct queries
- `dto/EntActRequest.java` - Request DTO for EntAct operations
- `dto/PagedResponse.java` - Wrapper for paginated responses

### Data Models

- `model/EntAct.java` - JPA entity model for ENTACT table

### Data Access (Repositories)

- `repository/EntActRepository.java` - Data access methods for EntAct entity

### Business Logic (Services)

- `service/EntActService.java` - Business logic for EntAct operations
- `service/HealthService.java` - Health monitoring and status checking

### Test Classes

- `EntActIntegrationTest.java` - Integration tests for EntAct API
- `controller/EntActControllerTest.java` - Unit tests for EntAct controller
- `controller/HealthControllerTest.java` - Unit tests for Health controller
- `repository/EntActRepositoryTest.java` - Tests for EntAct repository
- `service/EntActServiceTest.java` - Unit tests for EntAct service
- `service/HealthServiceTest.java` - Unit tests for Health service

### Configuration Properties

- `application.properties` - Main application configuration
- `application-dev.properties` - Development environment configuration
- `application-prod.properties` - Production environment configuration
- `application-test.properties` - Test environment configuration

## Prerequisites

- JDK 17 or higher
- Maven 3.6.0 or higher
- Oracle Database
- Git

## Installation & Setup

1. Clone the repository:
   ```bash
   git clone https://your-repository-url/entity-service.git
   cd entity-service
   ```

2. Configure database connection:
   Edit `src/main/resources/application.properties` with your Oracle database credentials:
   ```properties
   spring.datasource.url=jdbc:oracle:thin:@//your-oracle-host:1521/your-service-name
   spring.datasource.username=${DB_USERNAME}
   spring.datasource.password=${DB_PASSWORD}
   ```

3. Build the project:
   ```bash
   mvn clean package
   ```

4. Run the application:
   ```bash
   java -jar target/entity-service-1.0.0.jar
   ```

   Alternatively, run using Maven:
   ```bash
   mvn spring-boot:run
   ```

## API Endpoints

### Entity Activity (ENTACT)

#### Get All Entity Activities (Paginated)
```
GET /api/entact?page=0&size=100&sortBy=actsid&sortDir=DESC
```

#### Get Entity Activity by ID
```
GET /api/entact/{actsid}
```

#### Filter Entity Activities
```
GET /api/entact/filter?tin=123456789&tp=EXAMPLE&mft=30&startDate=2023-01-01&endDate=2023-12-31&page=0&size=100&sortBy=actdt&sortDir=DESC
```

### Health & Monitoring

#### Basic Heartbeat
```
GET /api/health/heartbeat
```

#### Comprehensive Status Check
```
GET /api/health/status
```

#### Quick Health Check (for load balancers)
```
GET /api/health/ping
```

#### System Information
```
GET /api/health/info
```

#### Prometheus Metrics
```
GET /actuator/prometheus
```

## Adding New Entities

To add a new entity to the service:

1. Create an entity model class in the `model` package (e.g., `YourEntity.java`)
2. Create a repository interface in the `repository` package (e.g., `YourEntityRepository.java`)
3. Create a service class in the `service` package (e.g., `YourEntityService.java`)
4. Create a controller class in the `controller` package (e.g., `YourEntityController.java`)
5. Create any needed DTOs in the `dto` package
6. Create tests for all components

The project is designed to automatically handle metrics and monitoring for any new entity added following this pattern.

## POM Dependencies

Use your existing `pom.xml` file and add these additional dependencies for the health monitoring and metrics functionality:

```xml
<!-- Spring Boot Actuator -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-actuator</artifactId>
</dependency>

<!-- Micrometer Prometheus Registry -->
<dependency>
    <groupId>io.micrometer</groupId>
    <artifactId>micrometer-registry-prometheus</artifactId>
</dependency>

<!-- Spring AOP -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-aop</artifactId>
</dependency>
```

## Building and Testing

### Building the Project
```bash
mvn clean package
```

### Running Tests
```bash
mvn test
```

### Running with a Specific Profile
```bash
java -jar target/entity-service-1.0.0.jar --spring.profiles.active=dev
```

## Health Monitoring

This application includes comprehensive health monitoring capabilities:

1. **Basic Heartbeat** - Simple application status check 
2. **Service Status** - Checks database and application health
3. **Metrics Collection** - Performance metrics for API calls and database operations
4. **Prometheus Integration** - Exports metrics for Prometheus

### Health Status Response Example

```json
{
  "overallStatus": "OK",
  "timestamp": "2023-05-24T14:32:45.123Z",
  "servicesDetails": {
    "database": {
      "service": "Oracle Database",
      "status": "OK",
      "message": "Database connection successful"
    },
    "application": {
      "service": "Entity Service API",
      "status": "OK",
      "message": "Application is running normally",
      "maxMemory": "2.0 GB",
      "freeMemory": "1.5 GB",
      "totalMemory": "1.8 GB",
      "usedMemory": "300.0 MB"
    }
  }
}
```

## Documentation

Additional documentation is available in the `docs` directory:

- **Health API Documentation** - Details on health endpoints 
- **Implementation Guide** - Step-by-step guide for implementing the architecture
- **Testing Guide** - Information on testing approach and test classes

## Contributing

1. Create a feature branch from `develop`
2. Make your changes
3. Submit a pull request

## License

[Your License Information]
