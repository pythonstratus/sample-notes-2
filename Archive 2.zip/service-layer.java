package gov.irs.sbse.os.ts.csp.elsentity.ele.service;

import gov.irs.sbse.os.ts.csp.elsentity.ele.model.EntAct;
import gov.irs.sbse.os.ts.csp.elsentity.ele.repository.EntActRepository;
import gov.irs.sbse.os.ts.csp.elsentity.ele.dto.EntActFilter;
import gov.irs.sbse.os.ts.csp.elsentity.ele.dto.PagedResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Date;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class EntActService {

    private final EntActRepository entActRepository;

    @Autowired
    public EntActService(EntActRepository entActRepository) {
        this.entActRepository = entActRepository;
    }

    @Transactional(readOnly = true)
    public PagedResponse<EntAct> getAllEntActs(int page, int size, String sortBy, String sortDir) {
        // Validate input
        validatePageNumberAndSize(page, size);
        
        // Create pageable instance
        Sort sort = sortDir.equalsIgnoreCase(Sort.Direction.ASC.name()) ? 
                    Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size, sort);

        // Retrieve paginated data
        Page<EntAct> entActsPage = entActRepository.findAll(pageable);
        
        if (entActsPage.getNumberOfElements() == 0) {
            return new PagedResponse<>(Collections.emptyList(), entActsPage.getNumber(),
                    entActsPage.getSize(), entActsPage.getTotalElements(), 
                    entActsPage.getTotalPages(), entActsPage.isLast());
        }

        List<EntAct> entActs = entActsPage.getContent();

        return new PagedResponse<>(entActs, entActsPage.getNumber(),
                entActsPage.getSize(), entActsPage.getTotalElements(), 
                entActsPage.getTotalPages(), entActsPage.isLast());
    }

    @Transactional(readOnly = true)
    public PagedResponse<EntAct> getEntActsByFilter(EntActFilter filter, int page, int size, String sortBy, String sortDir) {
        // Validate input
        validatePageNumberAndSize(page, size);
        
        // Create pageable instance
        Sort sort = sortDir.equalsIgnoreCase(Sort.Direction.ASC.name()) ? 
                    Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size, sort);

        // Convert string dates to SQL dates if provided
        Date startDate = filter.getStartDate() != null ? Date.valueOf(filter.getStartDate()) : null;
        Date endDate = filter.getEndDate() != null ? Date.valueOf(filter.getEndDate()) : null;

        // Query with filters
        Page<EntAct> entActsPage = entActRepository.findWithFilters(
            filter.getTin(), filter.getTp(), filter.getMft(), startDate, endDate, pageable);
        
        if (entActsPage.getNumberOfElements() == 0) {
            return new PagedResponse<>(Collections.emptyList(), entActsPage.getNumber(),
                    entActsPage.getSize(), entActsPage.getTotalElements(), 
                    entActsPage.getTotalPages(), entActsPage.isLast());
        }

        List<EntAct> entActs = entActsPage.getContent();

        return new PagedResponse<>(entActs, entActsPage.getNumber(),
                entActsPage.getSize(), entActsPage.getTotalElements(), 
                entActsPage.getTotalPages(), entActsPage.isLast());
    }

    @Transactional(readOnly = true)
    public PagedResponse<EntAct> getDynamicSortedEntActs(Long tin, String tp, int page, int size, String sortBy, String sortDir) {
        // Validate input
        validatePageNumberAndSize(page, size);
        
        // Create pageable instance (without sort as we're using dynamic sorting in the native query)
        Pageable pageable = PageRequest.of(page, size);

        // Query with dynamic sorting
        Page<EntAct> entActsPage = entActRepository.findWithDynamicSorting(
            tin, tp, sortBy, sortDir, pageable);
        
        if (entActsPage.getNumberOfElements() == 0) {
            return new PagedResponse<>(Collections.emptyList(), entActsPage.getNumber(),
                    entActsPage.getSize(), entActsPage.getTotalElements(), 
                    entActsPage.getTotalPages(), entActsPage.isLast());
        }

        List<EntAct> entActs = entActsPage.getContent();

        return new PagedResponse<>(entActs, entActsPage.getNumber(),
                entActsPage.getSize(), entActsPage.getTotalElements(), 
                entActsPage.getTotalPages(), entActsPage.isLast());
    }

    @Transactional(readOnly = true)
    public Optional<EntAct> getEntActById(Long actsid) {
        return entActRepository.findById(actsid);
    }

    // Helper methods
    private void validatePageNumberAndSize(int page, int size) {
        if (page < 0) {
            throw new IllegalArgumentException("Page number cannot be less than zero.");
        }

        if (size < 1) {
            throw new IllegalArgumentException("Size must be greater than zero.");
        }

        if (size > 1000) {
            throw new IllegalArgumentException("Page size too large. Max allowed size is 1000.");
        }
    }
}
