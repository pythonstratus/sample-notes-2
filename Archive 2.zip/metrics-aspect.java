package gov.irs.sbse.os.ts.csp.elsentity.ele.aspect;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Timer;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

/**
 * Aspect for collecting metrics on API calls and database operations
 * Requires Spring AOP dependency
 */
@Aspect
@Component
public class MetricsAspect {

    private final Counter apiRequestCounter;
    private final Timer apiRequestTimer;
    private final Counter databaseQueryCounter;
    private final Timer databaseQueryTimer;
    private final Counter healthCheckCounter;

    @Autowired
    public MetricsAspect(
            Counter apiRequestCounter,
            Timer apiRequestTimer,
            Counter databaseQueryCounter,
            Timer databaseQueryTimer,
            Counter healthCheckCounter) {
        this.apiRequestCounter = apiRequestCounter;
        this.apiRequestTimer = apiRequestTimer;
        this.databaseQueryCounter = databaseQueryCounter;
        this.databaseQueryTimer = databaseQueryTimer;
        this.healthCheckCounter = healthCheckCounter;
    }

    /**
     * Track API controller methods execution time and count
     */
    @Around("execution(* gov.irs.sbse.os.ts.csp.elsentity.ele.controller.EntActController.*(..))")
    public Object trackApiRequests(ProceedingJoinPoint joinPoint) throws Throwable {
        apiRequestCounter.increment();
        long startTime = System.nanoTime();
        
        try {
            return joinPoint.proceed();
        } finally {
            long elapsedTime = System.nanoTime() - startTime;
            apiRequestTimer.record(elapsedTime, TimeUnit.NANOSECONDS);
        }
    }

    /**
     * Track database repository methods execution time and count
     */
    @Around("execution(* gov.irs.sbse.os.ts.csp.elsentity.ele.repository.EntActRepository.*(..))")
    public Object trackDatabaseQueries(ProceedingJoinPoint joinPoint) throws Throwable {
        databaseQueryCounter.increment();
        long startTime = System.nanoTime();
        
        try {
            return joinPoint.proceed();
        } finally {
            long elapsedTime = System.nanoTime() - startTime;
            databaseQueryTimer.record(elapsedTime, TimeUnit.NANOSECONDS);
        }
    }

    /**
     * Track health check requests
     */
    @Around("execution(* gov.irs.sbse.os.ts.csp.elsentity.ele.controller.HealthController.*(..))")
    public Object trackHealthChecks(ProceedingJoinPoint joinPoint) throws Throwable {
        healthCheckCounter.increment();
        return joinPoint.proceed();
    }
}
