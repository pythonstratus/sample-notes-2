package gov.irs.sbse.os.ts.csp.elsentity.ele.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

// DTO for paginated response
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PagedResponse<T> {
    private List<T> content;
    private int page;
    private int size;
    private long totalElements;
    private int totalPages;
    private boolean last;
}

// DTO for EntAct filter parameters
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EntActFilter {
    private Long tin;
    private String tp;
    private Integer mft;
    private String startDate; // Format: YYYY-MM-DD
    private String endDate;   // Format: YYYY-MM-DD
}

// DTO for creating/updating EntAct
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EntActRequest {
    private String tp;
    private Long tin;
    private Integer tintt;
    private Integer tinfs;
    private Long roid;
    private String actdt; // Format: YYYY-MM-DD
    private Integer mft;
    private String period; // Format: YYYY-MM-DD
    private Double amount;
    private String form809;
    private String rtnsec;
    private Integer dispcode;
    // Add other fields as needed
}

// DTO for API response
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApiResponse {
    private Boolean success;
    private String message;
    private Object data;
    
    public ApiResponse(Boolean success, String message) {
        this.success = success;
        this.message = message;
    }
}
