-- Example 1: Simple pagination using ROWNUM (Oracle specific)
-- This approach works well for smaller datasets
SELECT * FROM (
    SELECT a.*, ROWNUM rnum
    FROM (
        SELECT * 
        FROM ENTITYDEV.ENTACT
        WHERE TIN = :tin
        ORDER BY ACTSID DESC
    ) a
    WHERE ROWNUM <= (:pageNumber * :pageSize)
)
WHERE rnum > ((:pageNumber - 1) * :pageSize);

-- Example 2: Optimized pagination using ROW_NUMBER() OVER() (better for large datasets)
-- This approach is more efficient for large datasets as it avoids scanning the entire result set
SELECT *
FROM (
    SELECT e.*, ROW_NUMBER() OVER (ORDER BY e.ACTSID DESC) AS row_num
    FROM ENTITYDEV.ENTACT e
    WHERE e.TIN = :tin
)
WHERE row_num BETWEEN (:pageNumber - 1) * :pageSize + 1 AND :pageNumber * :pageSize;

-- Example 3: Dynamic sorting with pagination using ROW_NUMBER() and CASE statements
SELECT *
FROM (
    SELECT e.*, ROW_NUMBER() OVER (
        ORDER BY
            CASE WHEN :sortField = 'actsid' AND :sortDir = 'ASC' THEN e.ACTSID END ASC,
            CASE WHEN :sortField = 'actsid' AND :sortDir = 'DESC' THEN e.ACTSID END DESC,
            CASE WHEN :sortField = 'actdt' AND :sortDir = 'ASC' THEN e.ACTDT END ASC,
            CASE WHEN :sortField = 'actdt' AND :sortDir = 'DESC' THEN e.ACTDT END DESC,
            CASE WHEN :sortField = 'amount' AND :sortDir = 'ASC' THEN e.AMOUNT END ASC,
            CASE WHEN :sortField = 'amount' AND :sortDir = 'DESC' THEN e.AMOUNT END DESC,
            CASE WHEN :sortField = 'tin' AND :sortDir = 'ASC' THEN e.TIN END ASC,
            CASE WHEN :sortField = 'tin' AND :sortDir = 'DESC' THEN e.TIN END DESC
    ) AS row_num
    FROM ENTITYDEV.ENTACT e
    WHERE (:tin IS NULL OR e.TIN = :tin)
    AND (:tp IS NULL OR UPPER(e.TP) LIKE UPPER('%' || :tp || '%'))
    AND (:startDate IS NULL OR e.ACTDT >= TO_DATE(:startDate, 'YYYY-MM-DD'))
    AND (:endDate IS NULL OR e.ACTDT <= TO_DATE(:endDate, 'YYYY-MM-DD'))
)
WHERE row_num BETWEEN (:pageNumber - 1) * :pageSize + 1 AND :pageNumber * :pageSize;

-- Example 4: Counting total records for pagination metadata
-- This query is used to get the total count for calculating total pages
SELECT COUNT(*) AS total_count
FROM ENTITYDEV.ENTACT e
WHERE (:tin IS NULL OR e.TIN = :tin)
AND (:tp IS NULL OR UPPER(e.TP) LIKE UPPER('%' || :tp || '%'))
AND (:startDate IS NULL OR e.ACTDT >= TO_DATE(:startDate, 'YYYY-MM-DD'))
AND (:endDate IS NULL OR e.ACTDT <= TO_DATE(:endDate, 'YYYY-MM-DD'));

-- Example 5: Optimized query for very large datasets using FIRST_ROWS hint
-- This gives a hint to the Oracle optimizer to retrieve the first rows as quickly as possible
SELECT /*+ FIRST_ROWS(:pageSize) */ *
FROM (
    SELECT e.*, ROW_NUMBER() OVER (ORDER BY e.ACTSID DESC) AS row_num
    FROM ENTITYDEV.ENTACT e
    WHERE e.TIN = :tin
)
WHERE row_num BETWEEN (:pageNumber - 1) * :pageSize + 1 AND :pageNumber * :pageSize;
