package gov.irs.sbse.os.ts.csp.elsentity.ele.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;

import javax.sql.DataSource;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Service
public class HealthService {

    private final JdbcTemplate jdbcTemplate;
    private final DataSource dataSource;
    
    // You can inject other dependencies here as needed
    // Such as RestTemplate, WebClient, etc. for checking external services

    @Autowired
    public HealthService(JdbcTemplate jdbcTemplate, DataSource dataSource) {
        this.jdbcTemplate = jdbcTemplate;
        this.dataSource = dataSource;
    }

    /**
     * Get health status of all services
     * @return Map of service names to their health status
     */
    public Map<String, Map<String, Object>> checkAllServices() {
        Map<String, Map<String, Object>> healthStatus = new HashMap<>();
        
        // Check database connection
        healthStatus.put("database", checkDatabaseConnection());
        
        // Check application status
        healthStatus.put("application", checkApplicationStatus());
        
        // Check any external services
        // For example: healthStatus.put("external-service", checkExternalService());
        
        return healthStatus;
    }

    /**
     * Check database connection health
     * @return Health status details
     */
    private Map<String, Object> checkDatabaseConnection() {
        Map<String, Object> details = new HashMap<>();
        details.put("service", "Oracle Database");
        
        try {
            // Try to get a connection and execute a simple query with timeout
            CompletableFuture<Boolean> future = CompletableFuture.supplyAsync(() -> {
                try (Connection connection = dataSource.getConnection()) {
                    // Execute a simple query to check the connection
                    jdbcTemplate.queryForObject("SELECT 1 FROM DUAL", Integer.class);
                    return true;
                } catch (Exception e) {
                    return false;
                }
            });
            
            boolean result = future.get(5, TimeUnit.SECONDS); // 5 second timeout
            
            if (result) {
                details.put("status", "OK");
                details.put("message", "Database connection successful");
            } else {
                details.put("status", "NOT-OK");
                details.put("message", "Failed to execute query");
            }
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            details.put("status", "NOT-OK");
            details.put("message", "Database connection timeout or error: " + e.getMessage());
        }
        
        return details;
    }

    /**
     * Check application status
     * @return Health status details
     */
    private Map<String, Object> checkApplicationStatus() {
        Map<String, Object> details = new HashMap<>();
        details.put("service", "Entity Service API");
        
        // Check JVM metrics
        Runtime runtime = Runtime.getRuntime();
        long maxMemory = runtime.maxMemory();
        long freeMemory = runtime.freeMemory();
        long totalMemory = runtime.totalMemory();
        
        // Add metrics to details
        details.put("maxMemory", formatSize(maxMemory));
        details.put("freeMemory", formatSize(freeMemory));
        details.put("totalMemory", formatSize(totalMemory));
        details.put("usedMemory", formatSize(totalMemory - freeMemory));
        
        // Determine status based on memory usage
        double memoryUsageRatio = (double)(totalMemory - freeMemory) / maxMemory;
        if (memoryUsageRatio > 0.95) {
            details.put("status", "NOT-OK");
            details.put("message", "Application is running, but memory usage is critical");
        } else if (memoryUsageRatio > 0.85) {
            details.put("status", "WARNING");
            details.put("message", "Application is running, but memory usage is high");
        } else {
            details.put("status", "OK");
            details.put("message", "Application is running normally");
        }
        
        return details;
    }
    
    /**
     * Helper method to format memory size
     * @param bytes Memory size in bytes
     * @return Formatted memory size string
     */
    private String formatSize(long bytes) {
        int unit = 1024;
        if (bytes < unit) return bytes + " B";
        
        int exp = (int) (Math.log(bytes) / Math.log(unit));
        String pre = "KMGTPE".charAt(exp-1) + "";
        return String.format("%.1f %sB", bytes / Math.pow(unit, exp), pre);
    }
    
    /**
     * Example method to check external service health
     * Uncomment and modify as needed for your external services
     */
    /*
    private Map<String, Object> checkExternalService() {
        Map<String, Object> details = new HashMap<>();
        details.put("service", "External Service Name");
        
        try {
            // Use RestTemplate or WebClient to make a request to the external service
            // Example with RestTemplate:
            // restTemplate.getForEntity("https://external-service/health", String.class);
            
            // If successful:
            details.put("status", "OK");
            details.put("message", "External service is reachable");
        } catch (Exception e) {
            details.put("status", "NOT-OK");
            details.put("message", "External service is unreachable: " + e.getMessage());
        }
        
        return details;
    }
    */
}
