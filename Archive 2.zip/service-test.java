package gov.irs.sbse.os.ts.csp.elsentity.ele.service;

import gov.irs.sbse.os.ts.csp.elsentity.ele.dto.EntActFilter;
import gov.irs.sbse.os.ts.csp.elsentity.ele.dto.PagedResponse;
import gov.irs.sbse.os.ts.csp.elsentity.ele.model.EntAct;
import gov.irs.sbse.os.ts.csp.elsentity.ele.repository.EntActRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class EntActServiceTest {

    @Mock
    private EntActRepository entActRepository;

    @InjectMocks
    private EntActService entActService;

    private EntAct entAct;
    private List<EntAct> entActList;
    private Page<EntAct> entActPage;

    @BeforeEach
    void setUp() {
        // Create sample EntAct
        entAct = new EntAct();
        entAct.setActsid(1L);
        entAct.setTp("Test Taxpayer");
        entAct.setTin(123456789L);
        entAct.setAmount(new BigDecimal("1000.00"));
        entAct.setActdt(Date.valueOf(LocalDate.now()));
        entAct.setMft(30);

        // Create sample list
        entActList = new ArrayList<>();
        entActList.add(entAct);

        // Create sample page
        Pageable pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "actsid"));
        entActPage = new PageImpl<>(entActList, pageable, 1);
    }

    @Test
    void getAllEntActs_ReturnsPagedResponse() {
        // Arrange
        when(entActRepository.findAll(any(Pageable.class))).thenReturn(entActPage);

        // Act
        PagedResponse<EntAct> response = entActService.getAllEntActs(0, 10, "actsid", "DESC");

        // Assert
        assertNotNull(response);
        assertEquals(1, response.getContent().size());
        assertEquals(0, response.getPage());
        assertEquals(10, response.getSize());
        assertEquals(1, response.getTotalElements());
        assertEquals(1, response.getTotalPages());
        assertTrue(response.isLast());
    }

    @Test
    void getAllEntActs_WithInvalidPageNumber_ThrowsIllegalArgumentException() {
        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> 
            entActService.getAllEntActs(-1, 10, "actsid", "DESC"));
    }

    @Test
    void getAllEntActs_WithInvalidPageSize_ThrowsIllegalArgumentException() {
        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> 
            entActService.getAllEntActs(0, 0, "actsid", "DESC"));
    }

    @Test
    void getAllEntActs_WithExcessivePageSize_ThrowsIllegalArgumentException() {
        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> 
            entActService.getAllEntActs(0, 1001, "actsid", "DESC"));
    }

    @Test
    void getEntActsByFilter_ReturnsFilteredResults() {
        // Arrange
        when(entActRepository.findWithFilters(
                any(Long.class), any(String.class), any(Integer.class), 
                any(Date.class), any(Date.class), any(Pageable.class)))
                .thenReturn(entActPage);

        EntActFilter filter = new EntActFilter();
        filter.setTin(123456789L);
        filter.setTp("Test");
        filter.setMft(30);
        filter.setStartDate("2023-01-01");
        filter.setEndDate("2023-12-31");

        // Act
        PagedResponse<EntAct> response = entActService.getEntActsByFilter(
                filter, 0, 10, "actsid", "DESC");

        // Assert
        assertNotNull(response);
        assertEquals(1, response.getContent().size());
        assertEquals(0, response.getPage());
        assertEquals(10, response.getSize());
        assertEquals(1, response.getTotalElements());
    }

    @Test
    void getDynamicSortedEntActs_ReturnsSortedResults() {
        // Arrange
        when(entActRepository.findWithDynamicSorting(
                any(Long.class), any(String.class), any(String.class), 
                any(String.class), any(Pageable.class)))
                .thenReturn(entActPage);

        // Act
        PagedResponse<EntAct> response = entActService.getDynamicSortedEntActs(
                123456789L, "Test", 0, 10, "amount", "ASC");

        // Assert
        assertNotNull(response);
        assertEquals(1, response.getContent().size());
    }

    @Test
    void getEntActById_WhenExists_ReturnsEntAct() {
        // Arrange
        when(entActRepository.findById(anyLong())).thenReturn(Optional.of(entAct));

        // Act
        Optional<EntAct> result = entActService.getEntActById(1L);

        // Assert
        assertTrue(result.isPresent());
        assertEquals(entAct.getActsid(), result.get().getActsid());
    }

    @Test
    void getEntActById_WhenNotExists_ReturnsEmptyOptional() {
        // Arrange
        when(entActRepository.findById(anyLong())).thenReturn(Optional.empty());

        // Act
        Optional<EntAct> result = entActService.getEntActById(999L);

        // Assert
        assertFalse(result.isPresent());
    }

    @Test
    void getAllEntActs_WithEmptyResults_ReturnsEmptyPagedResponse() {
        // Arrange
        Page<EntAct> emptyPage = new PageImpl<>(new ArrayList<>(), PageRequest.of(0, 10), 0);
        when(entActRepository.findAll(any(Pageable.class))).thenReturn(emptyPage);

        // Act
        PagedResponse<EntAct> response = entActService.getAllEntActs(0, 10, "actsid", "DESC");

        // Assert
        assertNotNull(response);
        assertEquals(0, response.getContent().size());
        assertEquals(0, response.getTotalElements());
    }
}
