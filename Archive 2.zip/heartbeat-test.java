package gov.irs.sbse.os.ts.csp.elsentity.ele.controller;

import gov.irs.sbse.os.ts.csp.elsentity.ele.service.HealthService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class HealthControllerTest {

    @Mock
    private HealthService healthService;

    @InjectMocks
    private HealthController healthController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getHeartbeat_ReturnsOkStatus() {
        // Act
        ResponseEntity<Map<String, Object>> response = healthController.getHeartbeat();
        
        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("UP", response.getBody().get("status"));
        assertEquals("Entity Service API", response.getBody().get("applicationName"));
        assertNotNull(response.getBody().get("timestamp"));
    }

    @Test
    void getHealthStatus_WhenAllServicesOk_ReturnsOkStatus() {
        // Arrange
        Map<String, Map<String, Object>> mockServiceStatus = new HashMap<>();
        
        Map<String, Object> dbStatus = new HashMap<>();
        dbStatus.put("status", "OK");
        dbStatus.put("message", "Database connection successful");
        
        Map<String, Object> appStatus = new HashMap<>();
        appStatus.put("status", "OK");
        appStatus.put("message", "Application is running normally");
        
        mockServiceStatus.put("database", dbStatus);
        mockServiceStatus.put("application", appStatus);
        
        when(healthService.checkAllServices()).thenReturn(mockServiceStatus);
        
        // Act
        ResponseEntity<Map<String, Object>> response = healthController.getHealthStatus();
        
        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("OK", response.getBody().get("overallStatus"));
        assertNotNull(response.getBody().get("timestamp"));
        assertNotNull(response.getBody().get("servicesDetails"));
    }

    @Test
    void getHealthStatus_WhenAnyServiceNotOk_ReturnsServiceUnavailableStatus() {
        // Arrange
        Map<String, Map<String, Object>> mockServiceStatus = new HashMap<>();
        
        Map<String, Object> dbStatus = new HashMap<>();
        dbStatus.put("status", "NOT-OK");
        dbStatus.put("message", "Database connection failed");
        
        Map<String, Object> appStatus = new HashMap<>();
        appStatus.put("status", "OK");
        appStatus.put("message", "Application is running normally");
        
        mockServiceStatus.put("database", dbStatus);
        mockServiceStatus.put("application", appStatus);
        
        when(healthService.checkAllServices()).thenReturn(mockServiceStatus);
        
        // Act
        ResponseEntity<Map<String, Object>> response = healthController.getHealthStatus();
        
        // Assert
        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("NOT-OK", response.getBody().get("overallStatus"));
        assertNotNull(response.getBody().get("timestamp"));
        assertNotNull(response.getBody().get("servicesDetails"));
    }

    @Test
    void ping_WhenDatabaseOk_ReturnsPongWithOkStatus() {
        // Arrange
        Map<String, Map<String, Object>> mockServiceStatus = new HashMap<>();
        
        Map<String, Object> dbStatus = new HashMap<>();
        dbStatus.put("status", "OK");
        
        mockServiceStatus.put("database", dbStatus);
        
        when(healthService.checkAllServices()).thenReturn(mockServiceStatus);
        
        // Act
        ResponseEntity<String> response = healthController.ping();
        
        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("PONG", response.getBody());
    }

    @Test
    void ping_WhenDatabaseNotOk_ReturnsErrorWithServiceUnavailableStatus() {
        // Arrange
        Map<String, Map<String, Object>> mockServiceStatus = new HashMap<>();
        
        Map<String, Object> dbStatus = new HashMap<>();
        dbStatus.put("status", "NOT-OK");
        
        mockServiceStatus.put("database", dbStatus);
        
        when(healthService.checkAllServices()).thenReturn(mockServiceStatus);
        
        // Act
        ResponseEntity<String> response = healthController.ping();
        
        // Assert
        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
        assertEquals("ERROR", response.getBody());
    }

    @Test
    void getSystemInfo_ReturnsSystemInformation() {
        // Act
        ResponseEntity<Map<String, Object>> response = healthController.getSystemInfo();
        
        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertNotNull(response.getBody().get("timestamp"));
        assertNotNull(response.getBody().get("runtime"));
        assertNotNull(response.getBody().get("jvm"));
        assertNotNull(response.getBody().get("os"));
    }
}
