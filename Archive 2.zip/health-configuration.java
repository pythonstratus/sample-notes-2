package gov.irs.sbse.os.ts.csp.elsentity.ele.config;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.boot.actuate.autoconfigure.health.ConditionalOnEnabledHealthIndicator;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * Configuration for health check functionality
 */
@Configuration
public class HealthConfiguration {

    /**
     * Database health indicator for Spring Actuator
     * @param jdbcTemplate The JDBC template
     * @return A health indicator for database
     */
    @Bean
    @ConditionalOnEnabledHealthIndicator("db")
    public HealthIndicator dbHealthIndicator(JdbcTemplate jdbcTemplate) {
        return () -> {
            try {
                Integer result = jdbcTemplate.queryForObject("SELECT 1 FROM DUAL", Integer.class);
                if (result != null && result == 1) {
                    return Health.up()
                            .withDetail("database", "Oracle")
                            .withDetail("status", "Connected")
                            .build();
                } else {
                    return Health.down()
                            .withDetail("database", "Oracle")
                            .withDetail("status", "Invalid response")
                            .build();
                }
            } catch (Exception e) {
                return Health.down()
                        .withDetail("database", "Oracle")
                        .withDetail("status", "Not Connected")
                        .withDetail("error", e.getMessage())
                        .build();
            }
        };
    }

    /**
     * Application health indicator for Spring Actuator
     * @return A health indicator for application
     */
    @Bean
    public HealthIndicator applicationHealthIndicator() {
        return () -> {
            Runtime runtime = Runtime.getRuntime();
            long maxMemory = runtime.maxMemory();
            long totalMemory = runtime.totalMemory();
            long freeMemory = runtime.freeMemory();
            
            double memoryUsageRatio = (double)(totalMemory - freeMemory) / maxMemory;
            
            if (memoryUsageRatio > 0.95) {
                return Health.down()
                        .withDetail("memoryUsage", String.format("%.2f%%", memoryUsageRatio * 100))
                        .withDetail("message", "Critical memory usage")
                        .build();
            } else if (memoryUsageRatio > 0.85) {
                return Health.status("WARNING")
                        .withDetail("memoryUsage", String.format("%.2f%%", memoryUsageRatio * 100))
                        .withDetail("message", "High memory usage")
                        .build();
            } else {
                return Health.up()
                        .withDetail("memoryUsage", String.format("%.2f%%", memoryUsageRatio * 100))
                        .withDetail("availableProcessors", runtime.availableProcessors())
                        .build();
            }
        };
    }

    /**
     * Disk space health indicator
     * @return A health indicator for disk space
     */
    @Bean
    public HealthIndicator diskSpaceHealthIndicator() {
        return () -> {
            java.io.File path = new java.io.File(".");
            long totalSpace = path.getTotalSpace();
            long freeSpace = path.getFreeSpace();
            long usableSpace = path.getUsableSpace();
            
            double diskUsageRatio = (double)(totalSpace - freeSpace) / totalSpace;
            
            if (diskUsageRatio > 0.95) {
                return Health.down()
                        .withDetail("diskUsage", String.format("%.2f%%", diskUsageRatio * 100))
                        .withDetail("freeSpace", formatSize(freeSpace))
                        .withDetail("totalSpace", formatSize(totalSpace))
                        .withDetail("message", "Critical disk space usage")
                        .build();
            } else if (diskUsageRatio > 0.85) {
                return Health.status("WARNING")
                        .withDetail("diskUsage", String.format("%.2f%%", diskUsageRatio * 100))
                        .withDetail("freeSpace", formatSize(freeSpace))
                        .withDetail("totalSpace", formatSize(totalSpace))
                        .withDetail("message", "High disk space usage")
                        .build();
            } else {
                return Health.up()
                        .withDetail("diskUsage", String.format("%.2f%%", diskUsageRatio * 100))
                        .withDetail("freeSpace", formatSize(freeSpace))
                        .withDetail("totalSpace", formatSize(totalSpace))
                        .build();
            }
        };
    }
    
    /**
     * Helper method to format size
     * @param bytes Size in bytes
     * @return Formatted size string
     */
    private String formatSize(long bytes) {
        int unit = 1024;
        if (bytes < unit) return bytes + " B";
        
        int exp = (int) (Math.log(bytes) / Math.log(unit));
        String pre = "KMGTPE".charAt(exp-1) + "";
        return String.format("%.1f %sB", bytes / Math.pow(unit, exp), pre);
    }
}
