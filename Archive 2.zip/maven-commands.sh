# Clean and build the project without running tests
mvn clean package -DskipTests

# Clean and build with tests
mvn clean package

# Build with specific profile (e.g., for different environments)
mvn clean package -P dev

# Run Spring Boot application directly with Maven
mvn spring-boot:run

# Run with specific profile
mvn spring-boot:run -P dev

# Build deployable JAR file
mvn clean package spring-boot:repackage

# Build with version information
mvn clean package -Dversion=1.0.1

# Build with debug mode
mvn clean package -X

# View dependency tree
mvn dependency:tree

# Check for dependency updates
mvn versions:display-dependency-updates
