package gov.irs.sbse.os.ts.csp.elsentity.ele.repository;

import gov.irs.sbse.os.ts.csp.elsentity.ele.model.EntAct;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface EntActRepository extends JpaRepository<EntAct, Long> {
    
    // Find by TIN with pagination
    Page<EntAct> findByTin(Long tin, Pageable pageable);
    
    // Find by TP with pagination
    Page<EntAct> findByTpContainingIgnoreCase(String tp, Pageable pageable);
    
    // Custom query for filtering by date range with pagination
    @Query(value = "SELECT e FROM EntAct e WHERE e.actdt BETWEEN :startDate AND :endDate")
    Page<EntAct> findByActdtBetween(
        @Param("startDate") java.sql.Date startDate, 
        @Param("endDate") java.sql.Date endDate, 
        Pageable pageable
    );
    
    // Custom query with multiple filters
    @Query(value = "SELECT e FROM EntAct e WHERE " +
           "(:tin IS NULL OR e.tin = :tin) AND " +
           "(:tp IS NULL OR UPPER(e.tp) LIKE UPPER(CONCAT('%', :tp, '%'))) AND " +
           "(:mft IS NULL OR e.mft = :mft) AND " +
           "(:startDate IS NULL OR e.actdt >= :startDate) AND " +
           "(:endDate IS NULL OR e.actdt <= :endDate)")
    Page<EntAct> findWithFilters(
        @Param("tin") Long tin,
        @Param("tp") String tp,
        @Param("mft") Integer mft,
        @Param("startDate") java.sql.Date startDate,
        @Param("endDate") java.sql.Date endDate,
        Pageable pageable
    );
    
    // Native query example for complex scenarios where JPQL might not be sufficient
    @Query(value = "SELECT * FROM ENTITYDEV.ENTACT e WHERE " +
           "(:tin IS NULL OR e.TIN = :tin) AND " +
           "(:tp IS NULL OR UPPER(e.TP) LIKE UPPER('%' || :tp || '%')) " +
           "ORDER BY " +
           "CASE WHEN :sortDir = 'ASC' AND :sortField = 'actsid' THEN e.ACTSID END ASC, " +
           "CASE WHEN :sortDir = 'DESC' AND :sortField = 'actsid' THEN e.ACTSID END DESC, " +
           "CASE WHEN :sortDir = 'ASC' AND :sortField = 'actdt' THEN e.ACTDT END ASC, " +
           "CASE WHEN :sortDir = 'DESC' AND :sortField = 'actdt' THEN e.ACTDT END DESC",
           countQuery = "SELECT COUNT(*) FROM ENTITYDEV.ENTACT e WHERE " +
           "(:tin IS NULL OR e.TIN = :tin) AND " +
           "(:tp IS NULL OR UPPER(e.TP) LIKE UPPER('%' || :tp || '%'))",
           nativeQuery = true)
    Page<EntAct> findWithDynamicSorting(
        @Param("tin") Long tin,
        @Param("tp") String tp,
        @Param("sortField") String sortField,
        @Param("sortDir") String sortDir,
        Pageable pageable
    );
}
