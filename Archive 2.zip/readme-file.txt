# Entity Service API

A scalable Spring Boot REST API service for retrieving data from Oracle database tables with efficient pagination and sorting capabilities.

## Project Overview

This project provides a robust backend service to retrieve and display entity data from Oracle database tables. It's designed to handle millions of rows efficiently by implementing database-side pagination and optimized queries.

Key features:
- REST API endpoints with pagination and sorting
- Efficient Oracle-specific queries for large datasets
- Support for complex filtering
- Integration with React frontend

## Project Structure

```
entity-service/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── gov/
│   │   │       └── irs/
│   │   │           └── sbse/
│   │   │               └── os/
│   │   │                   └── ts/
│   │   │                       └── csp/
│   │   │                           └── elsentity/
│   │   │                               └── ele/
│   │   │                                   ├── App.java
│   │   │                                   ├── controller/
│   │   │                                   │   └── EntActController.java
│   │   │                                   ├── dto/
│   │   │                                   │   ├── ApiResponse.java
│   │   │                                   │   ├── EntActFilter.java
│   │   │                                   │   ├── EntActRequest.java
│   │   │                                   │   └── PagedResponse.java
│   │   │                                   ├── model/
│   │   │                                   │   └── EntAct.java
│   │   │                                   ├── repository/
│   │   │                                   │   └── EntActRepository.java
│   │   │                                   └── service/
│   │   │                                       └── EntActService.java
│   │   └── resources/
│   │       ├── application.properties
│   │       ├── application-dev.properties
│   │       └── application-prod.properties
│   └── test/
│       └── java/
│           └── gov/
│               └── irs/
│                   └── sbse/
│                       └── os/
│                           └── ts/
│                               └── csp/
│                                   └── elsentity/
│                                       └── ele/
│                                           ├── controller/
│                                           │   └── EntActControllerTest.java
│                                           ├── repository/
│                                           │   └── EntActRepositoryTest.java
│                                           └── service/
│                                               └── EntActServiceTest.java
├── pom.xml
└── README.md
```

## Prerequisites

- JDK 17 or higher
- Maven 3.6.0 or higher
- Oracle Database
- Git

## Installation & Setup

1. Clone the repository:
   ```bash
   git clone https://your-repository-url/entity-service.git
   cd entity-service
   ```

2. Configure database connection:
   Edit `src/main/resources/application.properties` with your Oracle database credentials:
   ```properties
   spring.datasource.url=jdbc:oracle:thin:@//your-oracle-host:1521/your-service-name
   spring.datasource.username=${DB_USERNAME}
   spring.datasource.password=${DB_PASSWORD}
   ```

3. Build the project:
   ```bash
   mvn clean package
   ```

4. Run the application:
   ```bash
   java -jar target/entity-service-1.0.0.jar
   ```

   Alternatively, run using Maven:
   ```bash
   mvn spring-boot:run
   ```

## API Endpoints

### Entity Activity (ENTACT)

#### Get All Entity Activities (Paginated)
```
GET /api/entact?page=0&size=100&sortBy=actsid&sortDir=DESC
```

#### Get Entity Activity by ID
```
GET /api/entact/{actsid}
```

#### Filter Entity Activities
```
GET /api/entact/filter?tin=123456789&tp=EXAMPLE&mft=30&startDate=2023-01-01&endDate=2023-12-31&page=0&size=100&sortBy=actdt&sortDir=DESC
```

#### Get Entity Activities with Dynamic Sorting
```
GET /api/entact/dynamic-sort?tin=123456789&tp=EXAMPLE&page=0&size=100&sortBy=amount&sortDir=ASC
```

## API Request Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| page      | int  | Page number (0-based) |
| size      | int  | Records per page |
| sortBy    | string | Field to sort by |
| sortDir   | string | Sort direction (ASC or DESC) |
| tin       | long | Taxpayer Identification Number |
| tp        | string | Taxpayer Name |
| mft       | int  | Master File Tax |
| startDate | string | Start date (YYYY-MM-DD) |
| endDate   | string | End date (YYYY-MM-DD) |

## Building and Deployment

### Build JAR File
```bash
mvn clean package spring-boot:repackage
```

The JAR file will be created in the `target/` directory.

### Run with Specific Profile
```bash
java -jar target/entity-service-1.0.0.jar --spring.profiles.active=dev
```

### Database Setup

The application expects the following table structure in the Oracle database:

```sql
CREATE TABLE ENTITYDEV.ENTACT (
    ACTSID      NUMBER(10),
    TP          VARCHAR2(70 BYTE),
    TIN         NUMBER(9),
    TINTT       NUMBER(1),
    TINFS       NUMBER(1),
    ROID        NUMBER(8),
    AROID       NUMBER(8),
    ACTDT       DATE,
    MFT         NUMBER(2),
    PERIOD      DATE,
    AMOUNT      NUMBER(15,2),
    FORM809     VARCHAR2(8 BYTE),
    RTNSEC      CHAR(1 BYTE),
    DISPCODE    NUMBER(2),
    GRPIND      NUMBER(1),
    TC          NUMBER(3),
    CC          NUMBER(3),
    RPTCD       CHAR(1 BYTE),
    RPTDEF      CHAR(1 BYTE),
    TYPCD       CHAR(1 BYTE),
    EXTRDT      DATE,
    CODE        CHAR(3 BYTE),
    SUBCODE     CHAR(3 BYTE),
    EMPIDNUM    VARCHAR2(10 BYTE),
    INPUTDATE   DATE,
    INPUTTIME   NUMBER(8),
    TYPEID      NUMBER(8),
    TSACTCD     CHAR(3 BYTE)
);

-- Primary Key
ALTER TABLE ENTITYDEV.ENTACT ADD CONSTRAINT PK_ENTACT PRIMARY KEY (ACTSID);

-- Indexes for better performance
CREATE INDEX IDX_ENTACT_TIN ON ENTITYDEV.ENTACT(TIN);
CREATE INDEX IDX_ENTACT_ACTDT ON ENTITYDEV.ENTACT(ACTDT);
CREATE INDEX IDX_ENTACT_TP ON ENTITYDEV.ENTACT(TP);
```

## Frontend Integration

The API service is designed to work with a React frontend. Here's a recommended stack:

- **UI Components:** Material-UI
- **Data Fetching:** React Query or SWR
- **State Management:** Redux Toolkit (for complex apps) or Zustand (for simpler apps)
- **Table Component:** Material-UI Table or AG Grid
- **Form Handling:** React Hook Form with Yup validation

An example React component is provided in the `frontend-examples/` directory.

## Performance Optimization

For best performance with large Oracle datasets:

1. **Database Level:**
   - Create appropriate indexes on frequently queried columns
   - Consider table partitioning for very large tables
   - Use Oracle hints for complex queries
   - Keep Oracle statistics up-to-date

2. **Application Level:**
   - Use appropriate fetch sizes for JDBC
   - Implement caching for frequently accessed data
   - Use projections for partial data retrieval
   - Configure connection pool settings properly

3. **Frontend Level:**
   - Implement virtualization for large tables
   - Use progressive loading techniques
   - Optimize data transfer (only request needed fields)

## Adding New Tables/Endpoints

To add support for a new database table:

1. Create a new entity class in the `model` package
2. Create a repository interface in the `repository` package
3. Create a service class in the `service` package
4. Create a controller class in the `controller` package
5. Create any needed DTOs in the `dto` package

Follow the pattern established with the EntAct implementation.

## Troubleshooting

### Common Issues

- **Database Connection:** Ensure your Oracle credentials are correct and the database is accessible
- **Memory Issues:** If dealing with very large datasets, adjust JVM memory settings:
  ```bash
  java -Xmx2g -jar target/entity-service-1.0.0.jar
  ```
- **Performance Issues:** Review indexes and SQL execution plans in Oracle

### Logging

To enable debug logging, modify the application.properties:

```properties
logging.level.gov.irs.sbse.os.ts.csp.elsentity=DEBUG
logging.level.org.hibernate.SQL=DEBUG
```

## Contributing

1. Create a feature branch from `develop`
2. Make your changes
3. Submit a pull request

## License

[Your License Information]
