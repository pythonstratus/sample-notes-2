package gov.irs.sbse.os.ts.csp.elsentity.ele.model;

import java.math.BigDecimal;
import java.sql.Date;
import lombok.Data;
import javax.persistence.*;

@Data
@Entity
@Table(name = "ENTACT", schema = "ENTITYDEV")
public class EntAct {

    @Id
    @Column(name = "ACTSID")
    private Long actsid;
    
    @Column(name = "TP")
    private String tp;
    
    @Column(name = "TIN")
    private Long tin;
    
    @Column(name = "TINTT")
    private Integer tintt;
    
    @Column(name = "TINFS")
    private Integer tinfs;
    
    @Column(name = "ROID")
    private Long roid;
    
    @Column(name = "AROID")
    private Long aroid;
    
    @Column(name = "ACTDT")
    private Date actdt;
    
    @Column(name = "MFT")
    private Integer mft;
    
    @Column(name = "PERIOD")
    private Date period;
    
    @Column(name = "AMOUNT")
    private BigDecimal amount;
    
    @Column(name = "FORM809")
    private String form809;
    
    @Column(name = "RTNSEC")
    private String rtnsec;
    
    @Column(name = "DISPCODE")
    private Integer dispcode;
    
    @Column(name = "GRPIND")
    private Integer grpind;
    
    @Column(name = "TC")
    private Integer tc;
    
    @Column(name = "CC")
    private Integer cc;
    
    @Column(name = "RPTCD")
    private String rptcd;
    
    @Column(name = "RPTDEF")
    private String rptdef;
    
    @Column(name = "TYPCD")
    private String typcd;
    
    @Column(name = "EXTRDT")
    private Date extrdt;
    
    @Column(name = "CODE")
    private String code;
    
    @Column(name = "SUBCODE")
    private String subcode;
    
    @Column(name = "EMPIDNUM")
    private String empidnum;
    
    @Column(name = "INPUTDATE")
    private Date inputdate;
    
    @Column(name = "INPUTTIME")
    private Long inputtime;
    
    @Column(name = "TYPEID")
    private Long typeid;
    
    @Column(name = "TSACTCD")
    private String tsactcd;
}
